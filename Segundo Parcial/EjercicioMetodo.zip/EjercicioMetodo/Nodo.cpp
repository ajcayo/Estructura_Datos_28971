#include "Nodo.h"

Nodo::Nodo(int val)
{
    valor = val;
    siguiente = NULL;
}
